
const CONFIG = {
    SERVER_URL: "http://localhost:3000"
};